import React, { useState } from 'react';
import { Volume2, RotateCcw, Eye, EyeOff } from 'lucide-react';

const FlashCard = ({ word, onAnswer, showAnswer }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [showImage, setShowImage] = useState(true);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const speakWord = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(word.word);
      utterance.lang = word.language === 'es' ? 'es-ES' : 
                      word.language === 'fr' ? 'fr-FR' : 
                      word.language === 'de' ? 'de-DE' : 
                      word.language === 'it' ? 'it-IT' : 'en-US';
      speechSynthesis.speak(utterance);
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="relative">
        <div className={`bg-white rounded-2xl shadow-lg border border-gray-100 p-8 min-h-[400px] transition-all duration-500 transform ${isFlipped ? 'rotateY-180' : ''}`}>
          {!isFlipped ? (
            // Front of card
            <div className="text-center space-y-6">
              <div className="flex justify-between items-start">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(word.difficulty)}`}>
                  {word.difficulty}
                </span>
                <button
                  onClick={() => setShowImage(!showImage)}
                  className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showImage ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </button>
              </div>

              {showImage && word.imageUrl && (
                <div className="w-full h-32 bg-gray-100 rounded-lg overflow-hidden">
                  <img 
                    src={word.imageUrl} 
                    alt={word.word}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.style.display = 'none';
                    }}
                  />
                </div>
              )}

              <div className="space-y-4">
                <div className="text-4xl font-bold text-gray-900">
                  {word.word}
                </div>
                
                {word.pronunciation && (
                  <div className="text-sm text-gray-500 italic">
                    /{word.pronunciation}/
                  </div>
                )}

                <button
                  onClick={speakWord}
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                >
                  <Volume2 className="h-4 w-4" />
                  <span>Listen</span>
                </button>

                <div className="pt-4">
                  <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                    {word.category}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            // Back of card
            <div className="text-center space-y-6 transform rotateY-180">
              <div className="space-y-4">
                <div className="text-3xl font-bold text-blue-600">
                  {word.translation}
                </div>
                
                {word.example && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">Example:</div>
                    <div className="font-medium text-gray-800 italic">
                      "{word.example}"
                    </div>
                  </div>
                )}

                <div className="pt-4 space-y-3">
                  <div className="text-sm text-gray-600">How well did you know this word?</div>
                  <div className="flex space-x-2 justify-center">
                    <button
                      onClick={() => onAnswer(false)}
                      className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm"
                    >
                      Still Learning
                    </button>
                    <button
                      onClick={() => onAnswer(true)}
                      className="px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors text-sm"
                    >
                      Got It!
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Flip button */}
        <button
          onClick={handleFlip}
          className="absolute bottom-4 right-4 p-2 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-6 text-center">
        <p className="text-sm text-gray-600">
          Click the card or use the flip button to reveal the answer
        </p>
      </div>
    </div>
  );
};

export default FlashCard;