import React from 'react';
import { languages } from '../data/languages';

const LanguageSelector = ({ selectedLanguage, onLanguageChange }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Choose Your Language</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {languages.map(language => (
          <button
            key={language.code}
            onClick={() => onLanguageChange(language.code)}
            className={`p-4 rounded-lg border-2 transition-all duration-200 hover:scale-105 ${
              selectedLanguage === language.code
                ? 'border-blue-500 bg-blue-50 shadow-md'
                : 'border-gray-200 hover:border-gray-300 hover:shadow-sm'
            }`}
          >
            <div className="text-4xl mb-2">{language.flag}</div>
            <div className="font-medium text-gray-900">{language.name}</div>
            <div className="text-sm text-gray-500">{language.totalWords} words</div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default LanguageSelector;