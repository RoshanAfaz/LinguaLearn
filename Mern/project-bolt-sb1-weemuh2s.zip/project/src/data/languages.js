export const languages = [
  { code: 'es', name: 'Spanish', flag: '🇪🇸', totalWords: 500 },
  { code: 'fr', name: 'French', flag: '🇫🇷', totalWords: 450 },
  { code: 'de', name: 'German', flag: '🇩🇪', totalWords: 400 },
  { code: 'it', name: 'Italian', flag: '🇮🇹', totalWords: 350 }
];

export const sampleWords = {
  es: [
    {
      id: '1',
      word: 'hola',
      translation: 'hello',
      language: 'es',
      difficulty: 'easy',
      category: 'greetings',
      pronunciation: 'OH-lah',
      example: 'Hola, ¿cómo estás?',
      imageUrl: 'https://images.pexels.com/photos/6203456/pexels-photo-6203456.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '2',
      word: 'casa',
      translation: 'house',
      language: 'es',
      difficulty: 'easy',
      category: 'home',
      pronunciation: 'KAH-sah',
      example: 'Mi casa es muy grande.',
      imageUrl: 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '3',
      word: 'amor',
      translation: 'love',
      language: 'es',
      difficulty: 'medium',
      category: 'emotions',
      pronunciation: 'ah-MOHR',
      example: 'El amor es hermoso.',
      imageUrl: 'https://images.pexels.com/photos/3184435/pexels-photo-3184435.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '4',
      word: 'hermoso',
      translation: 'beautiful',
      language: 'es',
      difficulty: 'medium',
      category: 'adjectives',
      pronunciation: 'er-MOH-soh',
      example: 'Qué día tan hermoso.',
      imageUrl: 'https://images.pexels.com/photos/36478/amazing-beautiful-breathtaking-clouds.jpg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '5',
      word: 'trabajar',
      translation: 'to work',
      language: 'es',
      difficulty: 'hard',
      category: 'verbs',
      pronunciation: 'trah-bah-HAHR',
      example: 'Necesito trabajar mañana.',
      imageUrl: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=300'
    }
  ],
  fr: [
    {
      id: '6',
      word: 'bonjour',
      translation: 'hello',
      language: 'fr',
      difficulty: 'easy',
      category: 'greetings',
      pronunciation: 'bon-ZHOOR',
      example: 'Bonjour, comment allez-vous?',
      imageUrl: 'https://images.pexels.com/photos/6203456/pexels-photo-6203456.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '7',
      word: 'maison',
      translation: 'house',
      language: 'fr',
      difficulty: 'easy',
      category: 'home',
      pronunciation: 'meh-ZOHN',
      example: 'Ma maison est grande.',
      imageUrl: 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '8',
      word: 'amour',
      translation: 'love',
      language: 'fr',
      difficulty: 'medium',
      category: 'emotions',
      pronunciation: 'ah-MOOR',
      example: "L'amour est beau.",
      imageUrl: 'https://images.pexels.com/photos/3184435/pexels-photo-3184435.jpeg?auto=compress&cs=tinysrgb&w=300'
    }
  ],
  de: [
    {
      id: '9',
      word: 'hallo',
      translation: 'hello',
      language: 'de',
      difficulty: 'easy',
      category: 'greetings',
      pronunciation: 'HAH-loh',
      example: 'Hallo, wie geht es dir?',
      imageUrl: 'https://images.pexels.com/photos/6203456/pexels-photo-6203456.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '10',
      word: 'haus',
      translation: 'house',
      language: 'de',
      difficulty: 'easy',
      category: 'home',
      pronunciation: 'HOWS',
      example: 'Mein Haus ist groß.',
      imageUrl: 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=300'
    }
  ],
  it: [
    {
      id: '11',
      word: 'ciao',
      translation: 'hello',
      language: 'it',
      difficulty: 'easy',
      category: 'greetings',
      pronunciation: 'CHAH-oh',
      example: 'Ciao, come stai?',
      imageUrl: 'https://images.pexels.com/photos/6203456/pexels-photo-6203456.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: '12',
      word: 'casa',
      translation: 'house',
      language: 'it',
      difficulty: 'easy',
      category: 'home',
      pronunciation: 'KAH-sah',
      example: 'La mia casa è grande.',
      imageUrl: 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=300'
    }
  ]
};

export const categories = [
  'greetings',
  'home',
  'emotions',
  'adjectives',
  'verbs',
  'food',
  'travel',
  'family',
  'work',
  'nature'
];