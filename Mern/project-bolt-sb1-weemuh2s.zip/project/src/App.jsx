import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import LanguageSelector from './components/LanguageSelector';
import FlashCard from './components/FlashCard';
import Quiz from './components/Quiz';
import ProgressDashboard from './components/ProgressDashboard';
import UserProfile from './components/UserProfile';
import { sampleWords } from './data/languages';
import { progressManager, sessionManager, storage } from './utils/localStorage';
import { Play, Brain, Shuffle } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('learn');
  const [selectedLanguage, setSelectedLanguage] = useState('es');
  const [currentUser, setCurrentUser] = useState(() => 
    storage.get('currentUser', {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      preferredLanguage: 'es',
      level: 'beginner',
      createdAt: new Date()
    })
  );
  const [learningMode, setLearningMode] = useState('flashcards'); // 'flashcards' or 'quiz'
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [wordsToStudy, setWordsToStudy] = useState([]);
  const [quizWords, setQuizWords] = useState([]);
  const [sessionActive, setSessionActive] = useState(false);

  // Initialize words and session on language change
  useEffect(() => {
    const words = sampleWords[selectedLanguage] || [];
    setWordsToStudy(words);
    setCurrentWordIndex(0);
    
    // Prepare quiz words (random 5 words)
    const shuffledWords = [...words].sort(() => 0.5 - Math.random()).slice(0, Math.min(5, words.length));
    setQuizWords(shuffledWords);
  }, [selectedLanguage]);

  // Auto-save user data
  useEffect(() => {
    storage.set('currentUser', currentUser);
  }, [currentUser]);

  const startLearningSession = () => {
    sessionManager.startSession(selectedLanguage);
    setSessionActive(true);
  };

  const endLearningSession = () => {
    const session = sessionManager.endSession();
    setSessionActive(false);
    if (session) {
      alert(`Session completed! You studied ${session.wordsStudied} words with ${session.correctAnswers} correct answers.`);
    }
  };

  const handleFlashcardAnswer = (isCorrect) => {
    const currentWord = wordsToStudy[currentWordIndex];
    if (!currentWord) return;

    // Update progress
    progressManager.updateProgress(currentWord.id, isCorrect);
    
    // Update session
    const currentSession = sessionManager.getCurrentSession();
    if (currentSession) {
      sessionManager.updateSession({
        wordsStudied: currentSession.wordsStudied + 1,
        correctAnswers: currentSession.correctAnswers + (isCorrect ? 1 : 0)
      });
    }

    // Move to next word
    if (currentWordIndex + 1 < wordsToStudy.length) {
      setCurrentWordIndex(currentWordIndex + 1);
    } else {
      // Reset to beginning or end session
      setCurrentWordIndex(0);
      if (sessionActive) {
        endLearningSession();
      }
    }
  };

  const handleQuizComplete = (results) => {
    // Update progress for each word
    results.answers.forEach(answer => {
      progressManager.updateProgress(answer.word.id, answer.correct);
    });

    // Update session
    const currentSession = sessionManager.getCurrentSession();
    if (currentSession) {
      sessionManager.updateSession({
        wordsStudied: currentSession.wordsStudied + results.totalQuestions,
        correctAnswers: currentSession.correctAnswers + results.score
      });
    }

    alert(`Quiz completed! Score: ${results.score}/${results.totalQuestions} (${results.percentage}%)`);
  };

  const handleUserUpdate = (userData) => {
    setCurrentUser(prev => ({ ...prev, ...userData }));
    if (userData.preferredLanguage && userData.preferredLanguage !== selectedLanguage) {
      setSelectedLanguage(userData.preferredLanguage);
    }
  };

  const shuffleWords = () => {
    const shuffled = [...wordsToStudy].sort(() => 0.5 - Math.random());
    setWordsToStudy(shuffled);
    setCurrentWordIndex(0);
  };

  const renderLearnContent = () => {
    if (wordsToStudy.length === 0) {
      return (
        <div className="text-center py-12">
          <p className="text-gray-500 mb-4">No words available for this language yet.</p>
          <p className="text-sm text-gray-400">More content coming soon!</p>
        </div>
      );
    }

    return (
      <div className="space-y-8">
        {/* Learning Mode Selector */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setLearningMode('flashcards')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  learningMode === 'flashcards'
                    ? 'bg-blue-100 text-blue-700 border-2 border-blue-200'
                    : 'text-gray-600 hover:bg-gray-100 border-2 border-transparent'
                }`}
              >
                <Brain className="h-4 w-4" />
                <span>Flashcards</span>
              </button>
              <button
                onClick={() => setLearningMode('quiz')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  learningMode === 'quiz'
                    ? 'bg-blue-100 text-blue-700 border-2 border-blue-200'
                    : 'text-gray-600 hover:bg-gray-100 border-2 border-transparent'
                }`}
              >
                <Play className="h-4 w-4" />
                <span>Quiz</span>
              </button>
            </div>

            <div className="flex items-center space-x-2">
              {learningMode === 'flashcards' && (
                <button
                  onClick={shuffleWords}
                  className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Shuffle className="h-4 w-4" />
                  <span>Shuffle</span>
                </button>
              )}
              
              {!sessionActive ? (
                <button
                  onClick={startLearningSession}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                >
                  Start Session
                </button>
              ) : (
                <button
                  onClick={endLearningSession}
                  className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
                >
                  End Session
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Progress Indicator */}
        {learningMode === 'flashcards' && wordsToStudy.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
            <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
              <span>Progress</span>
              <span>{currentWordIndex + 1} of {wordsToStudy.length}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentWordIndex + 1) / wordsToStudy.length) * 100}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Learning Content */}
        <div>
          {learningMode === 'flashcards' ? (
            wordsToStudy[currentWordIndex] ? (
              <FlashCard 
                word={wordsToStudy[currentWordIndex]}
                onAnswer={handleFlashcardAnswer}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">No more words to study!</p>
              </div>
            )
          ) : (
            quizWords.length > 0 ? (
              <Quiz 
                words={quizWords}
                onQuizComplete={handleQuizComplete}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">Not enough words for a quiz. Need at least 4 words.</p>
              </div>
            )
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        currentUser={currentUser}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'learn' && (
          <div className="space-y-8">
            <LanguageSelector 
              selectedLanguage={selectedLanguage}
              onLanguageChange={setSelectedLanguage}
            />
            {renderLearnContent()}
          </div>
        )}

        {activeTab === 'progress' && (
          <ProgressDashboard selectedLanguage={selectedLanguage} />
        )}

        {activeTab === 'profile' && (
          <UserProfile 
            user={currentUser}
            onUserUpdate={handleUserUpdate}
          />
        )}
      </main>
    </div>
  );
}

export default App;